function [] = saveAdjacencyGeoESTStates()
load ('PVOut2006WestVirginia.mat','Coord')
CoordCell{1} = Coord;
NPlant(1) = size(CoordCell{1},1);
clear Coord

load ('PVOut2006Virginia.mat','Coord')
CoordCell{2} = Coord;
NPlant(2) = size(CoordCell{2},1);
clear Coord


load ('PVOut2006NorthCarolina.mat','Coord')
CoordCell{3} = Coord;
NPlant(3) = size(CoordCell{3},1);
clear Coord

load ('PVOut2006SouthCarolina.mat','Coord')
CoordCell{4} = Coord;
NPlant(4) = size(CoordCell{4},1);
clear Coord

load ('PVOut2006Ohio.mat','Coord')
CoordCell{5} = Coord;
NPlant(5) = size(CoordCell{5},1);
clear Coord

load ('PVOut2006Georgia.mat','Coord')
CoordCell{6} = Coord;
NPlant(6) = size(CoordCell{6},1);
clear Coord

NPlantIds = [0; cumsum(NPlant)'];

Coord = []; PlantID = []; WhichStates = 1:6;
for state = 1:6
    if ismember(state,WhichStates)
        Coord = cat(1,Coord, CoordCell{state}); PlantID = cat(1,PlantID, (NPlantIds(state)+1:NPlantIds(state+1))');
    end
end

%% Graph Forming
for ii=1:size(Coord,1)
    for jj=1:size(Coord,1)
        [arclen,~] = distance(Coord(ii,1),Coord(ii,2),Coord(jj,1),Coord(jj,2));
        Dist(ii,jj) = arclen;
    end
end

topKNum = 4; score = 100-Dist;
TopKGraphA = zeros(size(Coord,1),size(Coord,1));
for i = 1:size(Coord,1)
    topkInd = zeros(1,topKNum);
    scoreNodeI = score(i,:);
    % Make sure that channel i is not in its own candidate set
    scoreNodeI(i) = NaN;
    for j = 1:topKNum
        [~, ind] = max(scoreNodeI);
        topkInd(j) = ind;
        scoreNodeI(ind) = NaN;
    end
    TopKGraphA(i,topkInd) = 1;
end
DistBin = (Dist<0.77041)&(Dist>0);
A4 = TopKGraphA; A4(sum(TopKGraphA,2)>sum(DistBin,2),:) = DistBin(sum(TopKGraphA,2)>sum(DistBin,2),:);
G = graph(A4,"upper");
A4 = full(G.adjacency);
save ("A.mat","A4",'-append')
end