%% Initialize Model Parameters
parameters = struct;

%Hyper-parameter
embeddingDimension = 10; %numChannels;
numHiddenUnits = 256;
inputSize = numChannels+1;
windowSize = size(XTrain,1);

% Embed Operatrion
sz = [embeddingDimension inputSize];
mu = 0;
sigma = 0.01;
parameters.embed.weights = initializeGaussian(sz,mu,sigma);

% Graph attention operation
sz = [embeddingDimension windowSize];
numOut = embeddingDimension;
numIn = windowSize;

parameters.graphattn.weights.linear = initializeGlorot(sz,numOut,numIn);
attentionValueWeights = initializeGlorot([2 numOut],1,2*numOut);
attentionEmbedWeights = initializeZeros([2 numOut]);
parameters.graphattn.weights.attention = cat(2,attentionEmbedWeights,attentionValueWeights);

sz = [numHiddenUnits embeddingDimension*numChannels];
numOut = numHiddenUnits;
numIn = embeddingDimension*numChannels;
parameters.fc1.weights = initializeGlorot(sz,numOut,numIn);
parameters.fc1.bias = initializeZeros([numOut,1]);

% fully connect operations
sz = [numChannels,numHiddenUnits]; 
numOut = numChannels;
numIn = numHiddenUnits;
parameters.fc2.weights = initializeGlorot(sz,numOut,numIn);
parameters.fc2.bias = initializeZeros([numOut,1]);


%% Specify Training Options

numEpochs = 50;
miniBatchSize = 128;
learnRate = 0.001;

%% Train Model
dsXTrain = arrayDatastore(XTrain,IterationDimension=3);
dsTTrain = arrayDatastore(TTrain,IterationDimension=2);
dsTrain = combine(dsXTrain,dsTTrain);

mbq = minibatchqueue(dsTrain,...
    MiniBatchSize=miniBatchSize,...
    OutputAsDlarray=[1 0],...
    OutputEnvironment = ["auto" "gpu"]);

trailingAvg = [];
trailingAvgSq = [];

numObservationsTrain = size(XTrain,3);
numIterationsPerEpoch = ceil(numObservationsTrain/miniBatchSize);
numIterations = numIterationsPerEpoch*numEpochs;

% Create a training progress monitor
monitor = trainingProgressMonitor(...
    Metrics="Loss",...
    Info="Epoch",...
    XLabel="Iteration");

epoch = 0;
iteration = 0;

% Loop over epochs
while epoch < numEpochs && ~monitor.Stop
    epoch = epoch+1;

    % Shuffle data
    shuffle(mbq)

    % Loop over mini-batches
    while hasdata(mbq) && ~monitor.Stop

        iteration = iteration+1;

        % Read mini-batches of data
        [X,T] = next(mbq);

        if canUseGPU
            X = gpuArray(X);
        end

        % Evaluate the model loss and gradients using dlfeval and the
        % modelLoss function.
        [loss,gradients] = dlfeval(@modelLoss,parameters,X,T,A);

        % Update the network parameters using the Adam optimizer
        [parameters,trailingAvg,trailingAvgSq] = adamupdate(parameters,gradients, ...
            trailingAvg,trailingAvgSq,iteration,learnRate);

        % Update training progress monitor
        recordMetrics(monitor,iteration,Loss=loss);
        updateInfo(monitor,Epoch=epoch + " of " + numEpochs);
        monitor.Progress = 100*(iteration/numIterations);
    end
end
%% Saving 
%Prm1StsTemp8Step0p5hrMonth = parameters;
%save('SavedGATModels.mat','Prm1StsTemp8Step0p5hrMonth','-append')
%% Process Data with Step-Ahead
function [XData,TData] = processData(features, windowSize, StepAhead)
numObs = size(features,1) - windowSize - StepAhead + 1;
XData = zeros(windowSize,size(features,2),numObs);
for startIndex = 1:numObs
    endIndex = (startIndex-1)+windowSize;
    XData(:,:,startIndex) = features(startIndex:endIndex,:);
end
TData = features(windowSize+StepAhead:end,:);
TData = permute(TData,[2 1]);
end
%% The Model
function [Y,attentionScores] = model(parameters,X,A)

% Embedding
weights = parameters.embed.weights;
numNodes = size(weights,2) - 1;
embeddingOutput = embed(1:numNodes,weights,DataFormat="CU");

% Graph Structure
adjacency = A;
adjacency = adjacency + eye(size(adjacency)); % Add self-loop to graph structure

% Graph Attention
embeddingOutput = repmat(embeddingOutput,1,1,size(X,3));
weights = parameters.graphattn.weights;
[outputFeatures,attentionScores] = graphAttention(X,embeddingOutput,adjacency,weights);

% Relu
outputFeatures = relu(outputFeatures);

% Multiply
outputFeatures = embeddingOutput .* outputFeatures;

% Fully Connect
weights = parameters.fc1.weights;
bias = parameters.fc1.bias;
Y = fullyconnect(outputFeatures,weights,bias,DataFormat="UCB");

% Relu
Y = relu(Y);

% Fully Connect
weights = parameters.fc2.weights;
bias = parameters.fc2.bias;
Y = fullyconnect(Y,weights,bias,DataFormat="CB");
end

%% Model Loss Function
function [loss,gradients] = modelLoss(parameters,X,T,A)
Y = model(parameters,X,A);
loss = l2loss(Y,T,DataFormat="CB");
gradients = dlgradient(loss,parameters);
end
%% Model Predictions Function
function Y = modelPredictions(parameters,ds,A,minibatchSize)
arguments
    parameters
    ds
    A
    minibatchSize = 500
end

ds.ReadSize = minibatchSize;
Y = [];

reset(ds)
while hasdata(ds)
    data = read(ds);
    data = cat(3,data{:});
    if canUseGPU
        X = gpuArray(dlarray(data));
    else
        X = dlarray(data);
    end
    miniBatchPred = model(parameters,X,A);
    Y = cat(2,Y,miniBatchPred);
end
end


%% Graph Attention Function

function [outputFeatures,attentionScore] = graphAttention(inputFeatures,embedding,adjacency,weights)
linearWeights = weights.linear;
attentionWeights = weights.attention;

% Compute linear transformation of input features
value = pagemtimes(linearWeights, inputFeatures);  % Wx in the paper

% Concatenate linear transformation with channel embedding
gate = cat(1,embedding,value);

% Compute attention coefficients
query = pagemtimes(attentionWeights(1, :), gate);
key = pagemtimes(attentionWeights(2, :), gate);

attentionCoefficients = query + permute(key,[2, 1, 3]);
attentionCoefficients = leakyrelu(attentionCoefficients,0.2);

% Compute masked attention coefficients
mask = -10e9 * (1 - adjacency);
attentionCoefficients = (attentionCoefficients .* adjacency) + mask;

% Compute normalized masked attention coefficients
attentionScore = softmax(attentionCoefficients,DataFormat = "UCB"); % Equation (8) from the paper, attentionCoefficients ---> \pi_{ij}

% Normalize features using normalized masked attention coefficients
outputFeatures = pagemtimes(value, attentionScore);  % Equation (5) from the paper, attentionScore ----> Matrix form of \alpha_{ij}
end