1. Run the file "saveAdjacencyGeoESTStates.m" to create the graph adjacency matrix. 

2. For Weather data processing, please use the file, "PVCode_WeatherDataProcessing". Follow the instruction within the file to process specific types of weather data, to resample and to normalize the time series. 

3. For various horizons: Training codes are:

	a. PVCode_ProcessingDataForTraining_5_to30_minHorizon.m
	b. PVCode_ProcessingDataForTraining_Days_Horizon.m
	c. PVCode_ProcessingDataForTraining_Hours_Horizon.m



4. For various horizons: Test codes are:
	a. PVCode_ProcessingDataForTest_5_to30_minHorizon.m
	b. PVCode_ProcessingDataForTest_Days_Horizon.m
	c. PVCode_ProcessingDataForTest_Hours_Horizon.m

5. Please read the instructions in the comments of each file for adjusting data availability and resolution.