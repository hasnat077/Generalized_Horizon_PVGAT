clear; close all; clc

%% This Code is for Step Ahead Prediction of Power Output Using Our Model: Test
% TotalCouldData ---> Cld
% TempData ---> Tmpr
% AlbedoData ---> TAlbd
% TotalCouldData TempData AlbedoData ---> cta
%% Data Loading
%% Data Loading
NPlantIds = [0; 18; 239; 435; 719; 814; 1146];
WhichStates = 1:6; % 1 --> WV, 2 --> VA, 3 --> NC, 4 --> SC, 5 --> OH, 6 --> GA.
PlantID = [];
for state = 1:6
    if ismember(state,WhichStates), PlantID = cat(1,PlantID, (NPlantIds(state)+1:NPlantIds(state+1))'); end
end

%PlantID = (1:3)';

load A.mat
A = A(PlantID,PlantID);

load PVGenOutData.mat
Capacity = repmat(Capacity,size(PVGenOutData)./size(Capacity));
Capacity = Capacity(PlantID,:);
data = PVGenOutData(PlantID,:);
data = data./Capacity;
data = resample(data, 1, 12*3,'Dimension',2);

PlantType = repmat(PlantType,size(PVGenOutData)./size(PlantType));

[numChannels, numTimeSteps] = size(data);

SamplePerDay = (1/3)*24; ToD = mod((1:numTimeSteps), SamplePerDay)./ SamplePerDay;

fh = 3; % Forecasting Horizon in hours
StepAhead = fh/3;

figure, plot(data'), xlabel("Month"), ylabel("Power"), title("Power Data")

% %  Shuuffle
% DayStart = 160;
% SepIndex = DayStart*8+1:DayStart*8+296;
% AllIndex = 1:size(data,2);
% OthIndex = setdiff(AllIndex,SepIndex); 
% dataTemp = zeros(size(data));
% dataTemp = [data(:,OthIndex), data(:,SepIndex)];
% data = dataTemp;

% Training-Test Split
numTimeStepsTrain = floor(0.9*size(data,2));
dataTrain = data(:,1:numTimeStepsTrain);
dataTest = data(:,numTimeStepsTrain+1:end);

[~,muData,sigmaData] = normalize(dataTrain','range'); 
featuresTest = normalize(dataTest',center=muData,scale=sigmaData);

TemporalWindowSize = 4; % Size of the temporal window


[XTest,TTest] = processData(featuresTest,TemporalWindowSize,StepAhead);

%% Please Uncommnent section to add new type of weather data (please maintain same order to the training)


% Add Time of the day data
%temp = [ToD(OthIndex), ToD(SepIndex)]; ToD = temp;
tempToD(1,1,:) = ToD(numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
tempToD = repmat(tempToD,[1 numChannels 1]);
XTest = cat(1,tempToD,XTest);
% 
% % % Add PlantTypedata
% % tempPlantType(1,:,:) = PlantType(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
% % XTest = cat(1,tempPlantType,XTest);
% 
% % Add Weather Data (Cloud)
load ("WeatherData.mat",'TotalCloudDataNorm')
TotalCloudDataNorm = resample(TotalCloudDataNorm, 1, 12*3,'Dimension',2);
%temp = [TotalCloudDataNorm(:,OthIndex), TotalCloudDataNorm(:,SepIndex)]; TotalCloudDataNorm = temp;
tempCloud(1,:,:) = TotalCloudDataNorm(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
XTest = cat(1,tempCloud,XTest);

% Add Weather Data (Temp)
load ("WeatherData.mat",'TempDataNorm')
TempDataNorm= resample(TempDataNorm, 1, 12*3,'Dimension',2);
%temp = [TempDataNorm(:,OthIndex), TempDataNorm(:,SepIndex)]; TempDataNorm = temp;
tempTemp(1,:,:) = TempDataNorm(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
XTest = cat(1,tempTemp,XTest);
% 
% % % Add Weather Data (Albedo)
% % load ("WeatherData.mat",'AlbedoDataNorm')
% % tempAlbedo(1,:,:) = AlbedoDataNorm(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
% % XTest = cat(1,tempAlbedo,XTest);
% 
% % % Add Weather Data (Zenith)
% % load ("WeatherData.mat",'SolarZenithAngleNorm')
% % SolarZenithAngleNorm = resample(SolarZenithAngleNorm, 1, 12*3,'Dimension',2);
% % tempZenith(1,:,:) = SolarZenithAngleNorm(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
% % XTest = cat(1,tempZenith,XTest);
% 
% Add Weather Data (RCS)
load ("WeatherData.mat",'RCSDataNorm')
RCSDataNorm = resample(RCSDataNorm, 1, 12*3,'Dimension',2);
%temp = [RCSDataNorm(:,OthIndex), RCSDataNorm(:,SepIndex)]; RCSDataNorm = temp;
tempRCS(1,:,:) = RCSDataNorm(PlantID,numTimeStepsTrain+TemporalWindowSize+StepAhead:end);
XTest = cat(1,tempRCS,XTest);