clear; close all; clc


load ('PVOut2006WestVirginia.mat', 'Coord')
Coord1 = Coord; clear Coord
load ('PVOut2006Virginia.mat', 'Coord')
Coord2 = Coord; clear Coord
load ('PVOut2006NorthCarolina.mat', 'Coord')
Coord3 = Coord; clear Coord
load ('PVOut2006SouthCarolina.mat', 'Coord')
Coord4 = Coord; clear Coord
load ('PVOut2006Ohio.mat', 'Coord')
Coord5 = Coord; clear Coord
load ('PVOut2006Georgia.mat', 'Coord')
Coord6 = Coord; clear Coord
Coord = cat(1,Coord1,Coord2,Coord3,Coord4,Coord5,Coord6);

load('PVGenOutData.mat','PVGenOutData')
PVGenOut = PVGenOutData;
%% Total Cloud Area Fraction Data
ncdisp("tcdc.2006.nc")
totalcloud = ncread("tcdc.2006.nc","tcdc");
nlat = ncread("tcdc.2006.nc","lat");
nlon = ncread("tcdc.2006.nc","lon");

TotalCloudDataRaw = zeros(size(Coord,1),8*365);

for t = 1:8*365
    TotalCloudDataRaw(:,t) = griddata(double(nlon),double(nlat),(totalcloud(:,:,t)),Coord(:,2),Coord(:,1),'linear');
end

save("WeatherData.mat",'TotalCloudDataRaw')

TotalCloudData = resample(TotalCloudDataRaw,size(PVGenOut,2),size(TotalCloudDataRaw,2),'Dimension',2);
TotalCloudData = cat(2,TotalCloudData(:,5*12+1:end),zeros(size(PVGenOut,1),5*12));
save("WeatherData.mat",'TotalCloudData','-append')
%% Albedo 
ncdisp("albedo.2006.nc")
albedo = ncread("albedo.2006.nc","albedo");
nlat = ncread("albedo.2006.nc","lat");
nlon = ncread("albedo.2006.nc","lon");

AlbedoDataRaw = zeros(size(Coord,1),8*365);

for t = 1:8*365
    AlbedoDataRaw(:,t) = griddata(double(nlon),double(nlat),(albedo(:,:,t)),Coord(:,2),Coord(:,1),'linear');
end

save("WeatherData.mat",'AlbedoDataRaw','-append')

AlbedoData = resample(AlbedoDataRaw,size(PVGenOut,2),size(AlbedoDataRaw,2),'Dimension',2);
AlbedoData = cat(2,AlbedoData(:,5*12+1:end),zeros(size(PVGenOut,1),5*12));
save("WeatherData.mat",'AlbedoData','-append')

%% Solar Parameter Canopy Conductance
ncdisp("rcs.2006.nc")
rcs = ncread("rcs.2006.nc","rcs");
nlat = ncread("rcs.2006.nc","lat");
nlon = ncread("rcs.2006.nc","lon");

RCSDataRaw = zeros(size(Coord,1),8*365);

for t = 1:8*365
    RCSDataRaw(:,t) = griddata(double(nlon),double(nlat),(rcs(:,:,t)),Coord(:,2),Coord(:,1),'linear');
end

save("WeatherData.mat",'RCSDataRaw','-append')


RCSData = resample(RCSDataRaw,size(PVGenOut,2),size(RCSDataRaw,2),'Dimension',2);
RCSData = cat(2,RCSData(:,5*12+1:end),zeros(size(PVGenOut,1),5*12));
save("WeatherData.mat",'RCSData','-append')

%% Solar Zenith Angle
DateTimeInstant = linspace(datetime([2006,1,1,0,0,0]),datetime([2006,12,31,23,55,0]),365*24*12);
DateTimeInstant = [year(DateTimeInstant'),month(DateTimeInstant'),day(DateTimeInstant'), ...
    hour(DateTimeInstant'),minute(DateTimeInstant'), second(DateTimeInstant')];
SolarZenithAngle = zeros(size(PVGenOutData));
for p = 1:size(Coord,1)
    [angle, proj] = solarPosition(DateTimeInstant, Coord(p,1),Coord(p,2),-4, 0,0);
    ZenithAng = (angle(:,1))';
    SolarZenithAngle(p,:) = ZenithAng;
end

%% Temperature
nlat = ncread("air.2m.2006.nc","lat");
nlon = ncread("air.2m.2006.nc","lon");
air = ncread("air.2m.2006.nc","air");
time = ncread("air.2m.2006.nc","time");
x = ncread("air.2m.2006.nc","x");
y = ncread("air.2m.2006.nc","y");


TempDataRaw = zeros(size(Coord,1),size(air,3));

for t = 1:size(air,3)
    TempDataRaw(:,t) = griddata(double(nlon),double(nlat),(air(:,:,t)),Coord(:,2),Coord(:,1),'linear');
end

save("WeatherData.mat",'TempDataRaw','-append')

TempData = resample(TempDataRaw,size(PVGenOut,2),size(TempDataRaw,2), Dimension = 2);
TempData = cat(2,TempData(:,5*12+1:end),zeros(size(PVGenOut,1),5*12));
save("WeatherData.mat",'TempData','-append')

%% Normalization
clc
%load ("WeatherData.mat",'TotalCloudData','AlbedoData','TempData','RCSData')
TotalCloudDataNorm = (normalize(TotalCloudData','range'))';
AlbedoDataNorm = (normalize(AlbedoData','range'))';
TempDataNorm = (normalize(TempData','range'))';
RCSDataNorm = (normalize(RCSData','range'))';
SolarZenithAngleNorm = (normalize(SolarZenithAngle','range'))';
save("WeatherData.mat",'TotalCloudDataNorm','AlbedoDataNorm','TempDataNorm','RCSDataNorm','SolarZenithAngleNorm','-append')


